/* ============================================================
   JUW-MicroSlides — Service Worker
   Caches the app shell only. AI generation, PubMed, and media
   search all require network — this just makes the UI itself
   load instantly and work offline for editing/exporting.
   ============================================================ */

const CACHE_NAME = 'juw-microslides-v2';
const SHELL_FILES = [
  './',
  './index.html',
  './app.html',
  './manifest.json',
  './css/tokens.css',
  './css/landing.css',
  './css/app.css',
  './js/config.js',
  './js/pubmed.js',
  './js/media.js',
  './js/ai.js',
  './js/deck-model.js',
  './js/editor.js',
  './js/export-pptx.js',
  './js/export-pdf.js',
  './js/app.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/favicon.png',
  './icons/logo-juw.png',
  './icons/dept-badge-default.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(SHELL_FILES)).then(()=>self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
    )).then(()=>self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);
  // Only cache-first our own shell; everything cross-origin (APIs, CDNs, images) goes to network.
  if(url.origin === self.location.origin){
    event.respondWith(
      caches.match(event.request).then(cached => cached || fetch(event.request))
    );
  }
});
