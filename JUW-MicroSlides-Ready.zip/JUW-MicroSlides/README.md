# JUW MicroSlides

Professional **Microbiology lecture slide generator** for university students.

**Brand:** Jinnah University for Women seal on slides · **Slides by Noor** credit on every slide  

## Features

- Academic deck structure (title, learning outcomes, definitions, methods, pros/cons, applications, trends, references, thank you)
- Deep built-in outlines (e.g. Enzyme Immobilization MIC-4511 style) + generic topic engine
- Themes, layouts, and font selection
- **Download PPTX** (editable PowerPoint via PptxGenJS)
- **Download PDF**
- PWA: installable, offline shell
- Logo on the right · “Slides by Noor” on the left/bottom of slides

## Deploy (GitHub Pages)

1. Create repo `JUW-MicroSlides`
2. Upload all files in this folder (keep `assets/` paths)
3. Settings → Pages → Deploy from `main` root
4. Open `https://YOURUSER.github.io/JUW-MicroSlides/`

## Local test

Open `index.html` in Chrome (PPTX/PDF CDNs need network on first load).

## Version

1.0.0
